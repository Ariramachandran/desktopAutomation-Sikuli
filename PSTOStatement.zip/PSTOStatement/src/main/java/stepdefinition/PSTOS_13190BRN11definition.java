package stepdefinition;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.sikuli.script.ImagePath;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;

import io.cucumber.java.en.*;
import utility.CommonMethods;

public class PSTOS_13190BRN11definition {
	
	private static final String TEMP_DIR = null;

	@Given("I action for {string} and {string} function")
	public void i_action_for_and_function(String username4, String password4) {
		try {
			CommonMethods.enterUserAndPassword(username4, password4);
		}
	catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Step failed: " + e.getMessage(), e);
	}
	}

	@When("I check branch")
	public void i_check_branch() {
		try {
			CommonMethods.selectPurchaseStatement();
			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "spareDown.png").similar(0.7), 10).doubleClick();
			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "searchBar.png").similar(0.7), 10).doubleClick();
			CommonMethods.screen.type("Stock Transfer Outward Statement");
			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "STOstatement.png").similar(0.7), 10).doubleClick();

//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "spareDown.png").similar(0.7), 10).doubleClick();
////			CommonMethods.screen.wheel(1, 2);
////			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "downArrow1.png").similar(0.7)).doubleClick();
////			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "reports1.png").similar(0.8), 10).doubleClick();
////			CommonMethods.screen.wheel(1, 2);
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "3Wreports.png").similar(0.85)).doubleClick();
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "inventory.png").similar(0.79)).doubleClick();
////			screen.click(new Pattern(TEMP_DIR + "procurement.png"));
////			screen.doubleClick(new Pattern(TEMP_DIR + "procurement.png").similar(0.7));
//			CommonMethods.screen.wheel(1, 1);
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "statements.png").similar(0.85)).doubleClick();
//			CommonMethods.screen.wheel(1, 2);
//			Thread.sleep(1000);
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "STOS5.png").similar(0.99).targetOffset(0, -7)).doubleClick();
////			screen.wait(new Pattern(TEMP_DIR + "purchasestatement.png").similar(0.83)).doubleClick();
////			screen.click(new Pattern(TEMP_DIR + "purchasestatement.png"));
//			
//			//screen.doubleClick(new Pattern(TEMP_DIR + "stmt.png").similar(0.7));
////			new Region(0, 100, 300, 800).doubleClick(TEMP_DIR + "statements.png");
////			new Region(0, 100, 300, 800).click(TEMP_DIR + "purchasestatement.png");
			Thread.sleep(3000);
        
	} catch (Exception e) {
	    e.printStackTrace();
	    throw new RuntimeException("Step failed: " + e.getMessage(), e);
	}
	}

	@Then("I verify the report")
	public void i_verify_the_report() {
		try {
			String Directory10 = CommonMethods.getCredential("Directory10");
			generatereport(Directory10);
			Thread.sleep(1000);
//            generatereport("D:\\Ikaym\\Development\\BAJAJ\\13190BRN11\\To_Be_Processed");
	    }catch(Exception e) {   	
	    }
	}

	public static void generatereport(String Directory10) {
		try {
			
			ImagePath.setBundlePath(TEMP_DIR);

			// Step 1: Select branch from dropdown
			System.out.println("Applying filters and generating report...");
	        Pattern branchDropdown = new Pattern(CommonMethods.TEMP_DIR + "branch3.png").similar(0.7);
	        if (CommonMethods.screen.exists(branchDropdown, 10) != null) {
	            CommonMethods.screen.click(branchDropdown);
	            Thread.sleep(7000);
	        }
	        
	      //Click on the scroll-down button
			CommonMethods.screen.wheel(1, 5);
			Thread.sleep(3000);
			
			// Step 2: Select Dada A13184 PV option
	        Pattern dadaOption = new Pattern(CommonMethods.TEMP_DIR + "dada13190brn11.png").similar(0.7);
	        if (CommonMethods.screen.exists(dadaOption, 10) != null) {
	            CommonMethods.screen.click(dadaOption);
	            Thread.sleep(1000);
	        }

	        // Step 5: Click Date dropdown
	        Pattern dateDropdown = new Pattern(CommonMethods.TEMP_DIR + "dateDrop4.png").similar(0.7);
	        if (CommonMethods.screen.exists(dateDropdown, 10) != null) {
	            CommonMethods.screen.click(dateDropdown);
	            Thread.sleep(500);
	        }

	        // Step 6: Select Custom Date
	        Pattern customDateOption = new Pattern(CommonMethods.TEMP_DIR + "custom1.png").similar(0.7);
	        if (CommonMethods.screen.exists(customDateOption, 10) != null) {
	            CommonMethods.screen.click(customDateOption);
	            Thread.sleep(500);
	        }
	        
	        CommonMethods.screen.type(Key.TAB);
	        CommonMethods.screen.type(Key.ENTER);
	        Thread.sleep(1000);

//	        // Step 3: Click Show Taxes checkbox
//	        Pattern showTaxesCheckbox = new Pattern(CommonMethods.TEMP_DIR + "showtaxes.png").targetOffset(-20,0);
//	        if (CommonMethods.screen.exists(showTaxesCheckbox, 10) != null) {
//	            CommonMethods.screen.click(showTaxesCheckbox);
//	            Thread.sleep(500);
//	        }
//
//	        // Step 4: Click Show Tax Details checkbox
//	        Pattern showTaxDetailsCheckbox = new Pattern(CommonMethods.TEMP_DIR + "showtaxdetails.png").similar(0.8);
//	        if (CommonMethods.screen.exists(showTaxDetailsCheckbox, 10) != null) {
//	            CommonMethods.screen.click(showTaxDetailsCheckbox);
//	            Thread.sleep(500);
//	        }
	        
//	        // Step 7: Click on Document Date Dropdown
//	        Pattern documentDateDropdown = new Pattern(CommonMethods.TEMP_DIR + "docDate2.png").similar(0.85);
//	        if (CommonMethods.screen.exists(documentDateDropdown, 10) != null) {
//	        	CommonMethods.screen.click(documentDateDropdown);
//	            Thread.sleep(500);
//	        }
	        
	        // Step 7: Click on Document Date Dropdown
//	        Pattern documentNameDropdown = new Pattern(CommonMethods.TEMP_DIR + "docName1.png").similar(0.85);
//	        if (CommonMethods.screen.exists(documentNameDropdown, 10) != null) {
//	        	CommonMethods.screen.click(documentNameDropdown);
//	            Thread.sleep(500);
//	        }
//	        
//	        CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "fromDate1.png").similar(0.7).targetOffset(60,0)).click();
//			Thread.sleep(500); 

//			//click the branch and select the branch
//	        CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "branchDownArrow.png").similar(0.7), 10).click();
//	      
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "dadaA13184PV.png").similar(0.7), 10).doubleClick();
//            //screen.mouseMove(100);
//	    	CommonMethods.screen.wheel(1, 100);
//	    	
//			//datedrop.png
//			System.out.println("started generate report");
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "datedropPV.png").similar(0.7), 20).click();
//			CommonMethods.screen.click(new Pattern(CommonMethods.TEMP_DIR + "customPV.png").similar(0.8));
//			new Region(1000, 150, 400, 600).wait(new Pattern(CommonMethods.TEMP_DIR + "showtaxes.png").similar(0.7), 10).click();
//
//			CommonMethods.screen.click(new Pattern(CommonMethods.TEMP_DIR + "showtaxdetails.png").similar(0.7));
////			CommonMethods.screen.wheel(1, 2);
	        
//			CommonMethods.screen.type("a", Key.CTRL);
//			Thread.sleep(200);
//
//			// Press DELETE to remove the selected text
//			CommonMethods.screen.type(Key.DELETE);
//			Thread.sleep(300);
//			
//			String fromDate = CommonMethods.getCredential("from date");  // Fetch from Notepad
//			CommonMethods.screen.type(fromDate);
//			Thread.sleep(1000);
			
//			  // Extra backspaces 
//			for (int i = 0; i < 2; i++)
//			{	
//			 CommonMethods.screen.type(Key.BACKSPACE); Thread.sleep(100); 
//			 }
//			// Enter the new date (01)
//			CommonMethods.screen.type("01");
//			Thread.sleep(200);
//			
//			CommonMethods.screen.type(Key.SPACE);
//			Thread.sleep(200);
//			
//			// Press BACKSPACE multiple times to clear only the month part
//			for (int i = 0; i < 2; i++) {  
//				CommonMethods.screen.type(Key.BACKSPACE);  
//			    Thread.sleep(100);
//			}
//			
//			// Enter the new month (03)
//			CommonMethods.screen.type("03");
//			Thread.sleep(200);
//			
//			//screen.type("01.03.2025");
//			Thread.sleep(1000);
			
			// Step 8: Click Generate Report
//	        Pattern generateReportBtn = new Pattern(CommonMethods.TEMP_DIR + "GenerateReport2.png").targetOffset(-25,0);
//	        if (CommonMethods.screen.exists(generateReportBtn, 10) != null) {
//	        	CommonMethods.screen.click(generateReportBtn);
//	            System.out.println("Clicked Generate Report button");
	            Thread.sleep(5000); // wait for report generation
//	        }
//
//			CommonMethods.screen.type(Key.ENTER);
//			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "generatereportPV.png").similar(0.8), 10).click();
//			Thread.sleep(3000);
			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "XLSfile.png").similar(0.8), 10).click();
			Thread.sleep(5000);
			CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "exportHyperlink.png").similar(0.8), 10).click();
			CommonMethods.screen.type(Key.ENTER);
			
						// to enter file path
						Thread.sleep(1000);
						CommonMethods.screen.type("a", Key.CTRL);
						CommonMethods.screen.type(Key.BACKSPACE);
						// Format: YYYY-MM-DD_HH-MM-SS
				        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
				        String newFileName = "Part Stock Transfer Outward Statement_" + timestamp + ".xls";
				        CommonMethods.screen.type(newFileName);
						
						// Focus on the directory path
				        CommonMethods.screen.type("d", Key.ALT);  
						Thread.sleep(1000);
						
						CommonMethods.screen.type("a", Key.CTRL); // Select all text
						CommonMethods.screen.type(Key.BACKSPACE); // Clear existing path
						Thread.sleep(500);
						
						CommonMethods.screen.type(Directory10);
						Thread.sleep(1000);
						CommonMethods.screen.type(Key.ENTER);
				        
						// click save btn
						CommonMethods.screen.type("s", Key.ALT); 
						CommonMethods.screen.type(Key.ENTER);
						//closeApplications();

			Thread.sleep(2000);
			
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Step failed: " + e.getMessage(), e);
		}
	}
}
