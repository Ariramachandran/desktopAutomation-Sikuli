package Hooks;

import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import utility.CommonMethods;

import org.sikuli.script.ImagePath;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;

public class hooks {
	
	@BeforeAll
    public static void before_all() {
    	try {
    		
    		 new File("C:/AutomationReports").mkdirs();
        
        System.out.println("✅ Extent report initialized.");
    	}catch(Exception e) {
    		e.printStackTrace();
            System.out.println("❌ Failed to initialize extent report.");
    	}
    }
	 
	@Before()
	public void setup() {
		File tempFolder = new File(CommonMethods.TEMP_DIR);
        tempFolder.mkdirs();
        ImagePath.add(CommonMethods.TEMP_DIR);
        CommonMethods. extractAllResources("images", CommonMethods.TEMP_DIR);
        CommonMethods.navigateToDesktop();
        CommonMethods.openExcellonApplication();
    }
	 
	 @After
	 public void closeApplications() throws InterruptedException {
			//screen.type(Key.ENTER);
			
		// CommonMethods.bringExcelToFront();
		 //CommonMethods.closeExcel();
		 try {
		 //close excel
		 CommonMethods.robot.keyPress(KeyEvent.VK_TAB);
		 CommonMethods.robot.keyRelease(KeyEvent.VK_TAB);

		 Thread.sleep(500); 

		 CommonMethods.robot.keyPress(KeyEvent.VK_ENTER);
		 CommonMethods.robot.keyRelease(KeyEvent.VK_ENTER);
		 
		 //close app
		 CommonMethods.robot.keyPress(KeyEvent.VK_CONTROL);
		 CommonMethods.robot.keyPress(KeyEvent.VK_Q);
		 CommonMethods.robot.keyRelease(KeyEvent.VK_CONTROL);
		 CommonMethods.robot.keyRelease(KeyEvent.VK_Q);
		 
		 Thread.sleep(1000);
		 //click yes to close the app
		 CommonMethods.screen.wait(new Pattern(CommonMethods.TEMP_DIR + "yesimage.png").similar(0.7), 5).click();
		 }catch(Exception e) {
			 e.printStackTrace();     
		 }
	 }
		 @AfterAll
		    public static void after_all()
		 {
			 SwingUtilities.invokeLater(() -> {
		            JOptionPane.showMessageDialog(
		                null,
		                "✅ Part Stock Transfer Outward Statement Automation Complete!\n\n" +
		                "📄 Report Location:\nC:/AutomationReports/cucumber-report.html",
		                "🎉 Automation Finished",
		                JOptionPane.INFORMATION_MESSAGE
		            );
		        });
			 try {
		       // extent.flush(); // Write everything to file
				 Thread.sleep(5000);
		        
			 }catch(Exception e) {
				 e.printStackTrace();     
			 }
		 }
	 }
