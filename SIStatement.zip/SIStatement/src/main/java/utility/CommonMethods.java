package utility;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.sikuli.script.App;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Key;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import io.cucumber.plugin.event.Location;


public class CommonMethods {
	
	public static final Screen screen = new Screen();
	 public static Robot robot;
	 public static final String TEMP_DIR = System.getProperty("java.io.tmpdir") + "bajajautomateimages/";
	 
	public static void extractAllResources(String resourceFolder, String outputFolder) {
        try {
            ClassLoader classLoader = utility.CommonMethods.class.getClassLoader();;
            InputStream in = classLoader.getResourceAsStream(resourceFolder);
            if (in == null) return;
            String[] resourceFiles = {"docname.png", "DDate.png", "user_name.png", "password1.png", "username.png", "password1.png", 
            		"serviceDownArrow.png", "yesimage.png", "reports_option.png", "service_option.png", "job_card_bill_statement.png",
            		"leftArrow.png", "branchArrow.png","dada13184SIS.png", "jobCard.png", "dateDrop", "custom.png", "generateReport.png", 
            		"generateReport1.png", "XLSfile.png", "exportHyperlink.png",
            		"username1.png", "pass.png", "dadaA13184.png", "fromDate.png", "dadaB13184.png", "dadaC13184.png",
            		"dada13185.png", "dadaA13185PV.png", "dadaB13185PV.png", "service1.png", "dada13186PV.png", "3W_reports_option.png",
            		"dada13190.png", "reopenInvoice.png", "branchDown.png", "dada13190brn11.png", "dada13191PV.png", "branchDown1.png",
            		"dada13188PV.png", "dada13594PV.png", "ub_reports_option.png", "dada13454PV.png", "dada13184CPV.png",
            		"dada13719PV.png", "dada13952PV.png", "dada13186cPV.png", "AmritsarA13594PV.png", "TricityB13594PV.png",
            		"Exporthyperlink1.png", "Export1.png", "XLfile.png", "dateRange1.png", "dateDrop.png", "cusCode.png",
            		"showgroupbybox.png", "hidegroupbybox.png", "jobcardName.png", "jobcardbillStatement.png",
            		"13184C.png", "branchSelect.png", "13185C.png", "13186C.png", "JCBStatement01.png",
            		"JCBStatement02.png", "leftArrow01.png"};
            
            for (String fileName : resourceFiles) {
                extractResource("images/" + fileName, outputFolder + fileName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	public static void extractResource(String resourcePath, String outputPath) {
        try (InputStream in = utility.CommonMethods.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (in == null) return;
            File outputFile = new File(outputPath);
            outputFile.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(outputFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	public static void navigateToDesktop() {
		 try {
				robot = new Robot();
		        robot.keyPress(KeyEvent.VK_WINDOWS);
		        robot.keyPress(KeyEvent.VK_D);
		        robot.keyRelease(KeyEvent.VK_D);
		        robot.keyRelease(KeyEvent.VK_WINDOWS);
		        Thread.sleep(3000);
				}catch(Exception e) {
					e.printStackTrace();
				}
	 }
	public static void openExcellonApplication() {
		 try {
	            Pattern excIcon = new Pattern(TEMP_DIR + "exc_icon.png").similar(0.7);
	            Match match = screen.exists(excIcon, 5);
	            if (match != null) {
	            	System.out.println("Excellon icon found! Clicking...");
	            	match.highlight(2);
	                match.doubleClick();
	            } else {
	            	System.out.println("Image not found ! Trying to bring the app to the front");
	                App excellonApp = new App("esfw5ui");
	                excellonApp.focus();
	                Thread.sleep(3000);
	                if (!excellonApp.isValid()) {
	                	System.out.println("App focus failed! Launching Excellon using file path...");
	                    launchExcellonApp();
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	 }
	private static void launchExcellonApp() {
        try {
            String userDir = System.getProperty("user.home");
            String excellonShortcut = userDir + "\\Desktop\\Excellon 5.appref-ms";
            File shortcutFile = new File(excellonShortcut);
            if (shortcutFile.exists()) {
            	System.out.println("Launching Excellon app from: " + excellonShortcut);
            	String command = "cmd /c start \"\" \"" + excellonShortcut + "\"";
            	Runtime.getRuntime().exec(command);
            	 System.out.println("Excellon app launched successfully.");
            } else {
                System.out.println("Excellon app shortcut does not exist: " + excellonShortcut);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
//	//read data from notepad
//		 public static String getCredential(String key) throws IOException {
//			 try {
//		        // External Notepad file path
//		        String filePath = "C:\\My App\\credentials.txt";
//		        BufferedReader reader = new BufferedReader(new FileReader(filePath));
//		        String line;
//		        while ((line = reader.readLine()) != null) {
//		        	if (line.contains(key)) {
//		                return line.split("=")[1].trim();
//		        }
//		        }
//		        
//		        throw new Exception("Key not found in file: " + key);
//			 }catch(Exception e) {
//				 e.printStackTrace();
//			 }
//			return key;
//		    }
	
	public static String getCredential(String key) throws IOException {
	    String filePath = "C:\\My App\\credentials1.txt";
	    File file = new File(filePath);

	    if (!file.exists()) {
	        System.out.println(" File not found at: " + filePath);
	        throw new FileNotFoundException("File not found at: " + filePath);
	    }

	    BufferedReader reader = new BufferedReader(new FileReader(file));
	    String line;

	    while ((line = reader.readLine()) != null) {
	        line = line.trim();
	        if (line.startsWith(key + "=")) {
	            String value = line.split("=", 2)[1].trim();
	            System.out.println(" " + key + " = " + value); // Debug
	            reader.close();
	            return value;
	        }
	    }

	    reader.close();
	    throw new IOException(" Key not found in file: " + key);
	}


		 
		 //enter username and password
		 public static void enterUserAndPassword(String usernameKey, String passwordKey) {
			 try {
				 
				 String username = CommonMethods.getCredential(usernameKey);
			        String password = CommonMethods.getCredential(passwordKey);
			        
			        System.out.println("Username Key: " + usernameKey);
			        System.out.println("Password Key: " + passwordKey);
			        System.out.println("Username Value: " + username);
			        System.out.println("Password Value: " + password);
			        
			        
			        App excellonApp = new App("esfw5ui");
			        excellonApp.focus();
			        Thread.sleep(2000);
			        
			        // Check and click server field if found
			        Pattern serverPattern = new Pattern(CommonMethods.TEMP_DIR + "server.png").similar(0.8);
			        if (CommonMethods.screen.exists(serverPattern, 10) != null) {
			        	CommonMethods.screen.click(serverPattern);
			            Thread.sleep(500);
			        } else {
			            System.out.println("Server image not found, skipping...");
			        }
			     // Check and click username field if found
			        Pattern usernamePattern = new Pattern(CommonMethods.TEMP_DIR + "username1.png").similar(0.6);
			        if (CommonMethods.screen.exists(usernamePattern, 10) != null) {
			        	CommonMethods.screen.doubleClick(usernamePattern);
			        	CommonMethods.screen.type(Key.DELETE); 
			        	CommonMethods.screen.type(username);
			            Thread.sleep(500);
			        }
			        Pattern passwordPattern = new Pattern(CommonMethods.TEMP_DIR + "pass.png").similar(0.7);
			        if (CommonMethods.screen.exists(passwordPattern, 10) != null) {
			        	CommonMethods.screen.click(passwordPattern);
			        	CommonMethods.screen.type(password);
			            Thread.sleep(500);
			        }
			        CommonMethods.screen.type(Key.SHIFT + Key.TAB);
			        Thread.sleep(500);
			        
			        //Enter username
			        CommonMethods.typeText(CommonMethods.robot, username);
			        Thread.sleep(500);
			        
			     // Press TAB to move to the password field
			        CommonMethods.screen.type(Key.TAB);
			        Thread.sleep(500);
			        
			     // Enter password
			        CommonMethods.typeText(CommonMethods.robot, password);
			        Thread.sleep(500);
			        
			        CommonMethods.pressTab(CommonMethods.screen,1);
			        Thread.sleep(15000); 
			        
			        CommonMethods.pressTab(CommonMethods.screen,1);
			        CommonMethods.pressTab(CommonMethods.screen,1);
			        CommonMethods. screen.type(Key.ENTER);
			       
			        CommonMethods.screen.type(Key.ENTER);
			        CommonMethods.screen.type(Key.ENTER);
			        CommonMethods.screen.type(Key.ENTER);
			        Thread.sleep(500);
			        CommonMethods.screen.type(Key.ENTER);
			        CommonMethods.screen.type(Key.ENTER);
			        CommonMethods.screen.type(Key.ENTER);	
			        CommonMethods.screen.type(Key.ENTER);
			        CommonMethods.screen.type(Key.ENTER);
			        Thread.sleep(15000);
					/*
					 * screen.type(Key.ENTER); Thread.sleep(15000);
					 */
			        
			}
			catch(Exception e) {
					e.printStackTrace();
			}
		 }
	
	public static void selectPurchaseStatement() {
		try {
			
        
    } catch (Exception e) {
        e.printStackTrace();
    }
	}
	 
	public static void draganddrop() {
		try {
			//Rightclick on the document name
	    	if (CommonMethods.screen.exists(new Pattern(CommonMethods.TEMP_DIR + "cusCode.png").similar(0.8), 5) != null) {
		        CommonMethods.screen.rightClick(new Pattern(CommonMethods.TEMP_DIR + "cusCode.png").similar(0.7) );
		    } else if (CommonMethods.screen.exists(new Pattern(CommonMethods.TEMP_DIR + "cusName.png").similar(0.7), 5) != null) {
		        CommonMethods.screen.rightClick(new Pattern(CommonMethods.TEMP_DIR + "cusName.png").similar(0.7));
		    } 
			
	      //Drag and drop document date	
	        	Pattern cusCode = new Pattern(CommonMethods.TEMP_DIR + "cusCode.png").similar(0.8);
	        	Pattern cusName = new Pattern(CommonMethods.TEMP_DIR + "cusName.png").similar(0.7);
	        	
	        	//Pattern documentDate = new Pattern(CommonMethods.TEMP_DIR + "DDate.png").similar(0.7);
	        	Pattern jobcardName = new Pattern(CommonMethods.TEMP_DIR + "jobcardName.png").similar(0.7);
	        	Pattern targetDoc = null;
	        	
	        	// Check for docname image
	        	if (CommonMethods.screen.exists(cusCode, 5) != null) {
	        	    CommonMethods.screen.click(cusCode);
	        	    targetDoc = cusCode;
	        	} 
	        	//If not found, check for Docname1
	        	else if (CommonMethods.screen.exists(cusName, 5) != null) {
	        	    CommonMethods.screen.click(cusName);
	        	    targetDoc = cusName;
	        	}
	        	// Perform drag and drop if target found
	        	if (targetDoc != null) {
	        	    // Check for Show Group By box
	        	    if (CommonMethods.screen.exists("showgroupbybox.png", 3) != null) {
	        	        CommonMethods.screen.click();
	        	        
	        	        // Wait for both images to appear
	        	        CommonMethods.screen.wait(jobcardName, 5);
	        	        CommonMethods.screen.wait(targetDoc, 5);
	        	        
	        	        // Drag & Drop
	        	        CommonMethods.screen.dragDrop(jobcardName, targetDoc);
	        	    }
	        	}
	       //click Hide group by box
	        	
	        	// After drag-drop, right click and click hide group by box
	            CommonMethods.screen.rightClick(targetDoc);
	            Pattern hideGroup = new Pattern("hidegroupbybox.png");
	            CommonMethods.screen.wait(hideGroup, 3);
	            CommonMethods.screen.click(hideGroup);
			
		}catch(Exception e) {
			
		}
	}
 
// public static void scrollAndClick(Pattern pattern) throws Exception {
//		int maxScroll = 8;  // Adjust based on screen
//		boolean found = false;
//
//		for (int i = 0; i < maxScroll; i++) {
//			if (CommonMethods.screen.exists(pattern, 2) != null) {
//				CommonMethods.screen.doubleClick(pattern);
//				Thread.sleep(1000);
//				found = true;
//				break;
//			} else {
//				CommonMethods.screen.wheel(1, 2); // Scroll Down
//			}
//		}
//		
//		if (!found) {
//			System.out.println("Element not found: " + pattern.getFilename());
//		}
//	}
 
	/*
	 * private static void pressKey(int key, int times) throws InterruptedException
	 * { for (int i = 0; i < times; i++) { robot.keyPress(key);
	 * robot.keyRelease(key); Thread.sleep(500); } }
	 */

 public static void pressTab(Screen screen, int times) {
     try {
         for (int i = 0; i < times; i++) {
             screen.type(Key.TAB);
             Thread.sleep(500);
         }
     } catch (Exception e) {
         System.out.println("Error while pressing TAB: " + e.getMessage());
     }
 }
	
	public static void typeText(Robot robot, String text) {
		 try {
			
	     for (char ch : text.toCharArray()) {
	         int keyCode = KeyEvent.getExtendedKeyCodeForChar(ch);
	         if (KeyEvent.CHAR_UNDEFINED == keyCode) {
	             throw new RuntimeException("Key code not found for character '" + ch + "'");
	         }
	         robot.keyPress(keyCode);
	         robot.keyRelease(keyCode);
	     }
	 }catch(Exception e ) {
		 e.printStackTrace();
	 }
		 
	 }
	
 public static void selectbranch(String targetText) {
		
     try {
		boolean entryFound = false;
		int maxScrollAttempts = 50;
		int attempts = 0;

		while (attempts < maxScrollAttempts) {
		    // Capture visible screen text
		    String visibleText = CommonMethods.screen.text(); // OCR read
		    System.out.println("Visible Text: " + visibleText);

		    if (visibleText != null && visibleText.contains(targetText)) {
		        System.out.println("Text found: " + targetText);
		        
		        // Now find the pattern near the matched text (or approximate location)
		        Match match = CommonMethods.screen.findText(targetText); // This attempts to find location of the string
		        if (match != null) {
		            match.click();
		            System.out.println("Successfully clicked on: " + targetText);
		            entryFound = true;
		        }
		        break;
		    } else {
		    	CommonMethods.screen.type(Key.PAGE_DOWN);
		        System.out.println("Scrolling using Page Down...");
		        Thread.sleep(800);
		        attempts++;
		    }
		}

		if (!entryFound) {
		    System.out.println("Target text '" + targetText + "' not found after scrolling.");
		}
		CommonMethods.screen.wheel(1, 3);
       
    }catch(Exception e) {
    e.printStackTrace();	
    }													
}
	
	//close application
	 public static void bringExcelToFront() throws InterruptedException {
			pressKey(KeyEvent.VK_ALT, 1);
		    pressKey(KeyEvent.VK_TAB, 1);
		    Thread.sleep(1000);
			Thread.sleep(1000);
		}
	 
	 private static void pressKey(int key, int times) throws InterruptedException {
			for (int i = 0; i < times; i++) {
				robot.keyPress(key);
				robot.keyRelease(key);
				Thread.sleep(500);
			}
		}
		
		
	 public static void closeExcel() throws InterruptedException {
		 try {
	            // Close Excel if running
	            if (isProcessRunning("EXCEL.EXE")) {
	                System.out.println("Excel is running, closing it...");
	               // Runtime.getRuntime().exec("wmic process where name='EXCEL.EXE' delete");
	                Runtime.getRuntime().exec("taskkill /F /IM EXCEL.EXE");
	               Thread.sleep(2000); 
	            } else {
	                System.out.println("Excel is not running.");
	            }

	            // Close Excellon if running
	            if (isProcessRunning("esfw5ui.exe")) {  
	                System.out.println("Excellon is running, closing it...");
	                //Runtime.getRuntime().exec("wmic process where name='esfw5ui.exe' delete");
	                Runtime.getRuntime().exec("taskkill /F /IM esfw5ui.exe");
	                Thread.sleep(2000); 
	            } else {
	                System.out.println("Excellon is not running.");
	            }
	         // Check if a shutdown is scheduled and cancel only if necessary
	            Process process = Runtime.getRuntime().exec("shutdown /a");
	            int exitCode = process.waitFor();
	            if (exitCode == 0) {
	                System.out.println("Scheduled shutdown aborted successfully.");
	            } else {
	                System.out.println("No shutdown was scheduled.");
	            }
	         // Prevent shutdown
				/*
				 * Thread.sleep(2000); Runtime.getRuntime().exec("shutdown /a");
				 * Thread.sleep(500);
				 */
	            
	            screen.type(Key.ESC); 

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		 
	 }

	private static boolean isProcessRunning(String processName) {
		 try {
	            Process process = Runtime.getRuntime().exec("tasklist");
	            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
	            String line;
	            while ((line = reader.readLine()) != null) {
	                if (line.toLowerCase().contains(processName.toLowerCase())) {
	                	 reader.close();
	                    return true; // Process is running
	                }
	            }
	            reader.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false; // Process not found
			}
	
	
	public static void sleep(int i) {
		// TODO Auto-generated method stub
	}

}
	    