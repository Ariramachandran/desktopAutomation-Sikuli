package Runner;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
   features = {"classpath:Featurefile"},
//features = "src/main/resources/Featurefile/SIS_13190.feature",	
   
    glue = {"stepdefinition" ,"Hooks"},	
    dryRun = false,   
//    tags="@13190",
    
    monochrome = true
)
public class TestRunner {
}