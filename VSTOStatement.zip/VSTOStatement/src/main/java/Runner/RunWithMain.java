package Runner;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import javax.swing.JDialog;
import javax.swing.JOptionPane;
 
import org.apache.commons.io.output.TeeOutputStream;
import org.junit.runner.JUnitCore;


public class RunWithMain {
	public static void main(String[] args) {
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String logFilePath = "C:/AutomationReports/Vehicle Stock Transfer Outward Statement Console_" + timestamp + ".txt";
     // ===== Redirect console output =====
        try {
            PrintStream fileOut = new PrintStream(new FileOutputStream(logFilePath));
            PrintStream dualOut = new PrintStream(new TeeOutputStream(System.out, fileOut)); // both console and file
            System.setOut(dualOut);
            System.setErr(dualOut);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
     // 1. Show START popup
		 JOptionPane optionPane = new JOptionPane(
	                "Vehicle Stock Transfer Outward Statement is starting.\nPlease don't disturb the screen.\nMake sure the screen is active.",
	                JOptionPane.INFORMATION_MESSAGE);
		 JDialog dialog = optionPane.createDialog("Automation Starting");
	        dialog.setModal(false);
	        dialog.setAlwaysOnTop(true);
	        dialog.setVisible(true);
	     // Auto-close after 5 seconds (5000 ms)
	        new Thread(() -> {
	            try {
	                Thread.sleep(4000);
	                dialog.setVisible(false);
	                dialog.dispose();
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }).start(); 
        try {
        System.out.println("Running automation with UI...");
        JUnitCore.main("Runner.TestRunner");
        }catch(Exception e) {
        	 e.printStackTrace();
        }
	}
}
